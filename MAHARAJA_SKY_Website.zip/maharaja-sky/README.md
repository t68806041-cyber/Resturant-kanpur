# MAHARAJA SKY — Restaurant website starter

A responsive React/Vite website inspired by your supplied menu image: Japanese × Korean × Indian fine dining, royal gold and near-black palette, menu filters, cart, COD checkout, table reservation form, Supabase data storage, manager dashboard and a WhatsApp Cloud API Edge Function.

## Important honesty note
This is the implementation starter, not a deployed live website. It cannot create or change your Supabase project from this ZIP. Order/reservation submission and admin access work after the database and environment are configured. WhatsApp delivery requires Meta WhatsApp Cloud API credentials and an approved/eligible WhatsApp Business setup. Customer SMS is not wired in this starter. Google Maps embed, delivery-zone polygon validation, coupons/loyalty persistence, and customer status lookup still need production configuration. Testimonials are clearly marked illustrative and should be replaced with verified reviews. Menu entries/prices are transcribed from the image where legible and should be checked against your final menu.

## 1. Run on your PC
1. Install Node.js LTS from https://nodejs.org/.
2. Extract this ZIP to a folder.
3. Open Terminal/Command Prompt in that folder.
4. Run `npm install` then `npm run dev`.
5. Open the local URL printed by Vite, usually `http://localhost:5173`.

## 2. Connect your Supabase project
Project ref: `mdxyvgfrwmsyoaohaxxk`.
1. In Supabase Dashboard, open **SQL Editor → New query**.
2. Copy/paste `supabase/migrations/001_initial_schema.sql` and run it.
3. In this folder, copy `.env.example` to `.env`.
4. Set `VITE_SUPABASE_URL=https://mdxyvgfrwmsyoaohaxxk.supabase.co`.
5. Set `VITE_SUPABASE_PUBLISHABLE_KEY` to the publishable key from your project settings. This is intended for browser use; NEVER put a `service_role` or secret key in `VITE_` variables or frontend code.
6. Restart `npm run dev` after editing `.env`.

## 3. Create the manager account securely
1. Supabase Dashboard → Authentication → Users → Add user. Create an account for the restaurant manager.
2. Copy that user's UUID.
3. In SQL Editor run the following, replacing the UUID with the manager user's actual UUID:

```sql
insert into public.manager_users(user_id) values ('PASTE-MANAGER-USER-UUID-HERE');
```

4. Open the website footer → **Manager access** and sign in. Only UUIDs in `manager_users` can read/update orders and reservations.

## 4. WhatsApp manager notifications
This uses Meta WhatsApp Cloud API via a Supabase Edge Function. Do not place API tokens in `.env` or frontend code.
1. Configure WhatsApp Cloud API in Meta for Developers and obtain a phone-number ID and access token.
2. Install Supabase CLI and log in (`supabase login`).
3. From this project folder link it: `supabase link --project-ref mdxyvgfrwmsyoaohaxxk`.
4. Set secrets:

```bash
supabase secrets set WHATSAPP_ACCESS_TOKEN=your_meta_access_token
supabase secrets set WHATSAPP_PHONE_NUMBER_ID=your_meta_phone_number_id
supabase secrets set MANAGER_WHATSAPP=9715XXXXXXXX
```

5. Deploy the function: `supabase functions deploy notify-manager`.
6. Test an order and a booking. Meta policies, recipient opt-in, templates and account status may affect delivery. Never use a personal number in place of a configured WhatsApp Business API sender.

## 5. Configure restaurant details
Edit `.env` values for `VITE_MANAGER_WHATSAPP`, `VITE_RESTAURANT_ADDRESS`, `VITE_DELIVERY_MINIMUM_AED`, and `VITE_DELIVERY_FEE_AED`. WhatsApp floating button opens a chat to the manager number. The online checkout stores orders in Supabase; the Edge Function sends the manager a notification if configured.

## 6. Production checklist before taking real orders
- Confirm every menu name, dietary marker, price, allergens and image rights.
- Add real address, phone, map link, delivery service area and delivery time estimates.
- Validate delivery zones and minimums on a trusted server-side function (not only in browser).
- Add server-side price calculation and rate limiting / spam protection before accepting real orders. Never trust prices or totals submitted by the browser in a production payment flow.
- Add customer WhatsApp/SMS confirmations and status lookup using approved providers/templates.
- Review RLS and test anonymous inserts, manager reads and unauthorized access.
- Replace illustrative testimonials with genuine reviews and configure analytics/SEO/domain.
- Deploy the frontend to Vercel/Netlify or your preferred host and set production environment variables.

## Commands
- `npm install`
- `npm run dev`
- `npm run build`
- `npm run preview`
