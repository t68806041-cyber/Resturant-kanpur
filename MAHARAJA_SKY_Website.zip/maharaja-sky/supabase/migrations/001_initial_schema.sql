-- Run in Supabase SQL Editor. Public visitors can create orders/reservations;
-- only authenticated users listed as managers can read/update them.
create extension if not exists pgcrypto;
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), customer_name text not null, phone text not null,
 delivery_address text not null, notes text, items jsonb not null default '[]'::jsonb,
 subtotal numeric(10,2) not null check(subtotal >= 0), delivery_fee numeric(10,2) not null default 0 check(delivery_fee >= 0),
 total numeric(10,2) not null check(total >= 0), payment_method text not null default 'COD' check(payment_method='COD'),
 status text not null default 'pending' check(status in ('pending','accepted','preparing','out_for_delivery','delivered','rejected')),
 created_at timestamptz not null default now()
);
create table if not exists public.reservations (
 id uuid primary key default gen_random_uuid(), customer_name text not null, phone text not null, email text,
 reservation_date date not null, reservation_time text not null, guests integer not null check(guests between 1 and 30),
 occasion text, status text not null default 'pending' check(status in ('pending','confirmed','seated','completed','rejected')),
 created_at timestamptz not null default now()
);
create table if not exists public.manager_users (user_id uuid primary key references auth.users(id) on delete cascade, created_at timestamptz not null default now());
create or replace function public.is_manager() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.manager_users where user_id=auth.uid()); $$;
alter table public.orders enable row level security;
alter table public.reservations enable row level security;
alter table public.manager_users enable row level security;
drop policy if exists "Anyone can submit an order" on public.orders;
create policy "Anyone can submit an order" on public.orders for insert to anon, authenticated with check(status='pending' and payment_method='COD');
drop policy if exists "Managers can read orders" on public.orders;
create policy "Managers can read orders" on public.orders for select to authenticated using(public.is_manager());
drop policy if exists "Managers can update orders" on public.orders;
create policy "Managers can update orders" on public.orders for update to authenticated using(public.is_manager()) with check(true);
drop policy if exists "Anyone can request a reservation" on public.reservations;
create policy "Anyone can request a reservation" on public.reservations for insert to anon, authenticated with check(status='pending');
drop policy if exists "Managers can read reservations" on public.reservations;
create policy "Managers can read reservations" on public.reservations for select to authenticated using(public.is_manager());
drop policy if exists "Managers can update reservations" on public.reservations;
create policy "Managers can update reservations" on public.reservations for update to authenticated using(public.is_manager()) with check(true);
-- Do not expose manager list to public clients.
revoke all on public.manager_users from anon, authenticated;
grant select, insert on public.orders to anon, authenticated;
grant select, insert on public.reservations to anon, authenticated;
grant update on public.orders, public.reservations to authenticated;
-- Enable realtime for live manager updates; if already added, ignore duplicate publication errors.
do $$ begin alter publication supabase_realtime add table public.orders; exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.reservations; exception when duplicate_object then null; when undefined_object then null; end $$;
