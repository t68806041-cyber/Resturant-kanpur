import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: cors });
  try {
    const { type, record } = await req.json();
    if (!record || !['order', 'reservation'].includes(type)) return new Response(JSON.stringify({ error: 'Invalid notification payload' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } });
    const token = Deno.env.get('WHATSAPP_ACCESS_TOKEN');
    const phoneId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');
    const manager = (Deno.env.get('MANAGER_WHATSAPP') || '').replace(/\D/g, '');
    if (!token || !phoneId || !manager) return new Response(JSON.stringify({ ok: false, warning: 'WhatsApp secrets are not configured; record was saved but notification was not sent.' }), { status: 200, headers: { ...cors, 'Content-Type': 'application/json' } });
    const text = type === 'order'
      ? `MAHARAJA SKY — NEW COD ORDER\nCustomer: ${record.customer_name}\nPhone: ${record.phone}\nAddress: ${record.delivery_address}\nItems: ${(record.items || []).map((x: any) => `${x.qty} x ${x.name} (AED ${x.price})`).join(', ')}\nSubtotal: AED ${record.subtotal}\nDelivery: AED ${record.delivery_fee}\nTotal: AED ${record.total}\nTime: ${record.created_at || new Date().toISOString()}\nStatus: ${record.status}`
      : `MAHARAJA SKY — RESERVATION REQUEST\nCustomer: ${record.customer_name}\nPhone: ${record.phone}\nEmail: ${record.email || 'Not provided'}\nDate/time: ${record.reservation_date} ${record.reservation_time}\nGuests: ${record.guests}\nOccasion: ${record.occasion || 'Not specified'}\nReceived: ${record.created_at || new Date().toISOString()}\nStatus: ${record.status}`;
    const response = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ messaging_product: 'whatsapp', to: manager, type: 'text', text: { body: text } }) });
    const result = await response.json();
    if (!response.ok) return new Response(JSON.stringify({ ok: false, provider: result }), { status: 502, headers: { ...cors, 'Content-Type': 'application/json' } });
    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { ...cors, 'Content-Type': 'application/json' } });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }), { status: 500, headers: { ...cors, 'Content-Type': 'application/json' } });
  }
});
